<?php 

class User_model {
    private $nama = 'Yosi Septi Diana';

    public function getUser()
    {
        return $this->nama;
    }
}